# OVER TRUE DORMS — Online Master Admin + Owner Login

## इसमें क्या है
- `static/master-admin.html`: अलग Master Admin panel; Owner बनाना, Gmail, मोबाइल, custom plan dates, activation code और WhatsApp message link.
- `static/owner.html`: अलग Owner login; registered Gmail + activation code server से verify होते हैं.
- `main.py`: FastAPI backend और SQLite database. Owner की plan start/expiry date server पर check होती है.
- Activation code database में plain text में नहीं, SHA-256 hash के रूप में रखा जाता है.

## बहुत जरूरी: इसे online server पर deploy करना होगा
ये HTML फाइलें अकेले अलग-अलग मोबाइल पर login verify नहीं कर सकतीं। दोनों panels को एक ही HTTPS API URL देना होगा।

### Local test
Python 3.11+ install करें, फिर project folder में:
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Android/Termux/Linux: source .venv/bin/activate
pip install -r requirements.txt
```
Environment variables सेट करें:
```bash
# Linux / Termux
export ADMIN_API_KEY='अपनी-लंबी-यादृच्छिक-कुंजी'
uvicorn main:app --host 0.0.0.0 --port 8000
```
Windows PowerShell:
```powershell
$env:ADMIN_API_KEY="अपनी-लंबी-यादृच्छिक-कुंजी"
uvicorn main:app --host 0.0.0.0 --port 8000
```
फिर:
- Master Admin: `static/master-admin.html` खोलें; Admin ID `masteradmin`, API URL `http://127.0.0.1:8000`, Admin API Key वही डालें जो `ADMIN_API_KEY` में रखी.
- Owner: `static/owner.html` खोलें; वही API URL डालें; Gmail और code डालें.

## Render पर ऑनलाइन करना (GitHub की मदद से)
1. Render.com पर **Get Started** दबाकर Google/GitHub से account बनाएं।
2. इस पूरे project folder को GitHub पर एक नया repository बनाकर upload करें। `main.py`, `requirements.txt`, `render.yaml`, `static` सब एक ही root folder में रहने चाहिए।
3. Render Dashboard में **New + → Blueprint** चुनें और अपना GitHub repository connect करें।
4. Render `render.yaml` पढ़कर API service और PostgreSQL database बनाएगा। Database का `basic-256mb` plan paid है; deploy करने से पहले Render पर दिखाई गई कीमत जरूर देखें। Web service का Free plan sleep हो सकता है।
5. Deploy पूरा होने पर Render में `over-true-dorms-api` service खोलें और उसका URL कॉपी करें, जैसे `https://over-true-dorms-api.onrender.com`। यही Server API URL है।
6. यही URL Master Admin और Owner Panel दोनों में डालें। Master Admin में Render के Environment में बनी `ADMIN_API_KEY` की value भी डालें। इसे Owner के साथ share न करें।

**ध्यान दें:** Render account बनाना और GitHub repository connect करना user को अपने account में खुद करना होगा; ChatGPT आपके account में login या deploy नहीं कर सकता। PostgreSQL database का paid plan चुना गया है ताकि data persistent रहे।

## WhatsApp
सामान्य WhatsApp से message अपने आप नहीं भेजा जा सकता. Admin panel WhatsApp chat को pre-filled welcome + code के साथ खोलता है; Admin को Send दबाना होगा. Channel broadcast किसी खास Owner के निजी code message का विकल्प नहीं है.

## सुरक्षा और सीमाएं
- यह शुरुआती backend scaffold है; public production launch से पहले HTTPS, rate limiting, admin authentication/session, backups, privacy review और database hosting की जाँच जरूरी है.
- इस demo में Admin API Key ही Admin API protection है. इसे किसी Owner को न दें.
- Owner login फिलहाल email + activation code से होता है; इसमें email inbox ownership verification/OTP नहीं है. अगर यह जरूरी हो तो अलग OTP verification जोड़ना होगा.
- `ADMIN_PASSWORD` configuration variable इस initial version में deployment setup के लिए रखा है; panel admin verification API key द्वारा होती है. Admin ID `masteradmin` केवल UI label है, वास्तविक सुरक्षा secret API key है.
