import os, secrets, hashlib, hmac
from datetime import date, datetime
from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import create_engine, Column, Integer, String, Date, DateTime, select
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./over_true_dorms.db")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql+psycopg://", 1)
elif DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+psycopg://", 1)
ADMIN_API_KEY = os.getenv("ADMIN_API_KEY", "")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

class Owner(Base):
    __tablename__ = "owners"
    id = Column(Integer, primary_key=True)
    name = Column(String(160), nullable=False)
    mobile = Column(String(30), nullable=False)
    email = Column(String(254), unique=True, index=True, nullable=False)
    plan_name = Column(String(120), nullable=False)
    start_date = Column(Date, nullable=False)
    expiry_date = Column(Date, nullable=False)
    code_hash = Column(String(64), nullable=False)
    status = Column(String(20), default="Active", nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(bind=engine)
app = FastAPI(title="OVER TRUE DORMS API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

class OwnerCreate(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    mobile: str = Field(min_length=10, max_length=20)
    email: EmailStr
    plan_name: str = Field(default="Custom Plan", max_length=120)
    start_date: date
    expiry_date: date

class OwnerLogin(BaseModel):
    email: EmailStr
    activation_code: str = Field(min_length=8, max_length=32)

def db_session():
    db = SessionLocal()
    try: yield db
    finally: db.close()

def require_admin(x_admin_key: str = Header(default="")):
    if not ADMIN_API_KEY or not hmac.compare_digest(x_admin_key, ADMIN_API_KEY):
        raise HTTPException(401, "Admin API Key गलत है या server पर सेट नहीं है।")

def code_digest(code: str) -> str:
    return hashlib.sha256(code.upper().encode()).hexdigest()

def new_code():
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    raw = "".join(secrets.choice(alphabet) for _ in range(8))
    return "OTD-" + raw[:4] + "-" + raw[4:]

@app.get("/")
def root():
    return {"service": "OVER TRUE DORMS API", "status": "running"}

@app.get("/api/admin/owners", dependencies=[Depends(require_admin)])
def list_owners(db=Depends(db_session)):
    owners = db.scalars(select(Owner).order_by(Owner.id.desc())).all()
    today = date.today()
    return [{"id":o.id,"name":o.name,"mobile":o.mobile,"email":o.email,"plan_name":o.plan_name,
             "start_date":o.start_date.isoformat(),"expiry_date":o.expiry_date.isoformat(),
             "status":"Active" if o.status=="Active" and o.start_date<=today<=o.expiry_date else "Expired/Inactive"} for o in owners]

@app.post("/api/admin/owners", dependencies=[Depends(require_admin)])
def create_owner(payload: OwnerCreate, db=Depends(db_session)):
    email = str(payload.email).lower()
    if payload.expiry_date < payload.start_date:
        raise HTTPException(400, "Expiry Date, Start Date से पहले नहीं हो सकती।")
    if db.scalar(select(Owner).where(Owner.email == email)):
        raise HTTPException(409, "यह Gmail पहले से किसी Owner से जुड़ी है।")
    mobile = "".join(ch for ch in payload.mobile if ch.isdigit())
    if len(mobile) not in (10, 11, 12):
        raise HTTPException(400, "मोबाइल नंबर सही नहीं है।")
    code = new_code()
    while db.scalar(select(Owner).where(Owner.code_hash == code_digest(code))):
        code = new_code()
    owner = Owner(name=payload.name.strip(), mobile=mobile, email=email, plan_name=payload.plan_name.strip() or "Custom Plan",
                  start_date=payload.start_date, expiry_date=payload.expiry_date, code_hash=code_digest(code))
    db.add(owner); db.commit(); db.refresh(owner)
    msg = f"नमस्ते {owner.name}! OVER TRUE DORMS में आपका स्वागत है। आपका Activation Code: {code}. Login Gmail: {email}. Plan: {owner.plan_name}. Valid: {owner.start_date} से {owner.expiry_date}."
    return {"id":owner.id,"activation_code":code,"whatsapp_message":msg}

@app.post("/api/owner/login")
def owner_login(payload: OwnerLogin, db=Depends(db_session)):
    owner = db.scalar(select(Owner).where(Owner.email == str(payload.email).lower()))
    if not owner or not hmac.compare_digest(owner.code_hash, code_digest(payload.activation_code.strip())):
        raise HTTPException(401, "Gmail ID या Activation Code गलत है।")
    today = date.today()
    if owner.status != "Active" or today < owner.start_date:
        raise HTTPException(403, "आपका Plan अभी शुरू नहीं हुआ है।")
    if today > owner.expiry_date:
        raise HTTPException(403, "आपका Plan expire हो गया है। Master Admin से संपर्क करें।")
    return {"ok":True,"owner":{"name":owner.name,"email":owner.email,"plan_name":owner.plan_name,
             "start_date":owner.start_date.isoformat(),"expiry_date":owner.expiry_date.isoformat()}}
